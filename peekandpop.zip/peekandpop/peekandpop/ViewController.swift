//
//  ViewController.swift
//  peekandpop
//
//  Created by MAC OS on 02/08/2017.
//  Copyright © 2017 MAC OS. All rights reserved.
//

import UIKit
import JustPeek

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,PeekingDelegate {

    let arr = ["1","2","3","4","5","6","7","8","9"];
    
    
    private enum SegueIdentifiers: String {
        case ShowDetails = "ShowDetailsSegueIdentifier"
    }
    
    @IBOutlet weak var tbl: UITableView!
    let  peekController = PeekController()
    override func viewDidLoad() {
        super.viewDidLoad()
        
       
        peekController.register(viewController: self, forPeekingWithDelegate: self, sourceView: tbl)
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == SegueIdentifiers.ShowDetails.rawValue {
            guard let indexPath = sender as? IndexPath else { return }
            configureViewController(segue.destination, withItemAtIndexPath: indexPath)
        }
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1;
        
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        
        return arr.count;
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) ;
        cell.textLabel?.text = arr[indexPath.row];
        
        
        return cell;
    }
    
    
    func peekContext(_ context: PeekContext, viewControllerForPeekingAt location: CGPoint) -> UIViewController? {
        let viewController = storyboard?.instantiateViewController(withIdentifier: "next")
        if let viewController = viewController, let indexPath = tbl.indexPathForRow(at: location) {
            
            
            configureViewController(viewController, withItemAtIndexPath: indexPath)
            if let cell = tbl.cellForRow(at: indexPath) {
                context.sourceRect = cell.frame
            }
            return viewController
        }
        return nil
    }
    
    func peekContext(_ context: PeekContext, commit viewController: UIViewController) {
        show(viewController, sender: self)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
  func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: SegueIdentifiers.ShowDetails.rawValue, sender: indexPath)
    }
    
    private func configureViewController(_ viewController: UIViewController, withItemAtIndexPath indexPath: IndexPath) {
        guard let cell = tbl.cellForRow(at: indexPath) else { return }
        viewController.title = cell.textLabel?.text
        viewController.view.accessibilityLabel = "Preview for \(viewController.title!)"
    }
    


}

