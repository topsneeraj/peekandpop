//
//  first.swift
//  peekandpop
//
//  Created by MAC OS on 02/08/2017.
//  Copyright © 2017 MAC OS. All rights reserved.
//

import UIKit

class first: UIViewController {
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var loadingView: UIView!
    
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
titleLabel.alpha = 0.0
        // Do any additional setup after loading the view.
    }

    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        let delay = DispatchTime.now() + Double(Int64(1.3 * Double(NSEC_PER_SEC))) / Double(NSEC_PER_SEC)
        DispatchQueue.main.asyncAfter(deadline: delay) { [weak self] in
            self?.updateView()
        }
    }
    fileprivate func updateView() {
        titleLabel.text = "\(title ?? NSStringFromClass(ViewController.self)) Details"
        UIView.animate(withDuration: 0.25, animations: { [weak self] in
            self?.loadingView.alpha = 0.0
            self?.titleLabel.alpha = 1.0
        })
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
